interface PartnerPeerUser {
	username: string;
}
