type PeerConnection = import('.').default;
